package com.mycompany.sistemataller;

import dao.RepuestoDAO;
import modelo.Repuesto;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        // Instancia del DAO configurado con tu conexión en Aiven Cloud
        RepuestoDAO dao = new RepuestoDAO();
        
        // Ejecución del método listar()
        List<Repuesto> lista = dao.listar();

        System.out.println("\n==========================================================================");
        System.out.println("                     INVENTARIO DE BODEGA - REPUESTOS                     ");
        System.out.println("==========================================================================");
        System.out.printf("%-5s | %-32s | %-12s | %-10s%n", "ID", "DESCRIPCIÓN", "PRECIO UNIT.", "EXISTENCIAS");
        System.out.println("--------------------------------------------------------------------------");

        if (lista.isEmpty()) {
            System.out.println("No hay repuestos registrados o no se pudo establecer la conexión.");
        } else {
            for (Repuesto r : lista) {
                System.out.printf("%-5d | %-32s | Q%-11.2f | %-10d%n",
                        r.getIdRepuesto(),
                        r.getDescripcion(),
                        r.getPrecioUnitario(),
                        r.getExistencias());
            }
        }

        System.out.println("==========================================================================");
    }
}