package modelo;

public class Repuesto {
    private int idRepuesto;
    private String descripcion;
    private double precioUnitario;
    private int existencias;

    public Repuesto() {
    }

    public Repuesto(int idRepuesto, String descripcion, double precioUnitario, int existencias) {
        this.idRepuesto = idRepuesto;
        this.descripcion = descripcion;
        this.precioUnitario = precioUnitario;
        setExistencias(existencias); 
    }

    public int getIdRepuesto() {
        return idRepuesto;
    }

    public void setIdRepuesto(int idRepuesto) {
        this.idRepuesto = idRepuesto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public int getExistencias() {
        return existencias;
    }

    public void setExistencias(int existencias) {
        if (existencias < 0) {
            this.existencias = 0; 
            this.existencias = existencias;
        }
    }
}